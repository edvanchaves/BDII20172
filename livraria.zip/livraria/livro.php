<?php

class Livro {

    private $id;
    private $titulo;
    private $preco;
    private $edicao;

    public function __construct($pid, $ptitulo, $ppreco, $pedicao){
    	$this->id = $pid;
    	$this->titulo = $ptitulo;
    	$this->preco = $ppreco;
    	$this->edicao = $pedicao;
    }

    public function imprimir(){
    	echo "<tr><td>" . $this->id . "</td><td>" . $this->titulo . "</td><td><a href='compraLivro01.php?id=". $this->id ."'>Comprar</td></tr>";
    }
}
?>
