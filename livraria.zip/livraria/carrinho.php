

<?php
$itens = $_GET['livros'];

echo "Itens: " . $itens . "</br>";

foreach($itens as $i)
	echo $i . "</br>";
?>