<?php

include_once("livro.php");
include_once("livroDAO.php");

$id =  isset($_GET["id"]) ? $_GET["id"] : '';

echo "ID: " . $id;

?>

<form action="compraLivro02.php" method="POST">

  <input type="hidden" name="id" value="<?php echo $id ?>">
  <input type="number" name="quantidade"/>

  <input type="submit" value="Comprar">

</form>
