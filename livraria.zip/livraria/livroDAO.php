<?php

include_once("livro.php");
include_once("conexao.php");


function consultarLivros(){

	$pdo = conectar();

	$resultado = $pdo->query("SELECT * FROM livro;");

	$livros = [];

	while ($linha = $resultado->fetch(PDO::FETCH_ASSOC))
	{

		$id = $linha['id'];
  	$titulo = $linha['titulo'];
  	$preco = $linha['preco'];
  	$edicao = $linha['edicao'];
		$livro = new Livro($id, $titulo, $preco, $edicao);
		$livros[] = $livro;
	}

	return $livros;
}
?>
