<?php

include_once("livro.php");
include_once("livroDAO.php");

$id =  isset($_POST["id"]) ? $_POST["id"] : '';

$quantidade =  isset($_POST["quantidade"]) ? $_POST["quantidade"] : '';

echo "ID: " . $id . " QTD: " . $quantidade;

?>
