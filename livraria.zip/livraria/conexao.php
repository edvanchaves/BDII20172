<?php

function conectar() {

	$usuario = 'postgres';
	$senha = 'fgfcomp';
	$opcoes = array(\PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'); 
	$dados_conexao = 'pgsql:host=localhost;dbname=livraria2';

	try {
		$pdo = new \PDO($dados_conexao, $usuario, $senha, $opcoes);
	} catch (\Exception $e) {
		echo "Erro na conexao: " . $e->getMessage();
	}

	return $pdo;
}
?>