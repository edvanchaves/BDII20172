  <!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>

  <?php include("conexao.php");?>

  <?php

  echo $dados_conexao;
  $conexao = pg_connect($dados_conexao);  

  $resultado = pg_query($conexao, "select * from empregado order by ssn");

  $arr_resultado = pg_fetch_all($resultado);

  ?>
    <div class="container">
      <h4>Empregados</h4>

        <table class="striped" align="center">
    <br/>
            <tr align="center">
                <th>SSN</th>
                <th>Nome</th>
                <th>Empregado</th>
                <th></th>
                <th></th>
            </tr>
            <?php foreach($arr_resultado as $l){?>
              <tr align="center">
                  <td><a href="altEmp01.php?ssn=<?=$l['ssn']?>"</a><?=$l['ssn']?></td>
                  <td><?= $l['pnome']?></td>                
                  <td><?= $l['salario']?></td>
                  <td><a href="detalheEmp.php?ssn=<?=$l['ssn']?>"</a>Alterar</td>
                  <td><a href="detalheEmp.php?ssn=<?=$l['ssn']?>"</a>Excluir</td>
              </tr>
            <?php } ?>
  </table>

    </div>

    <body>
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="js/materialize.min.js"></script>
    </body>
  </html>