<?php

include_once("livro.php");
include_once("livroDAO.php");

echo 'Consultando...';

$livros = consultarLivros();

?>

<table class="bordered" align="center">
<tr><th>Id</th><th>Nome</th><th>Comprar</th></tr>

<?php
foreach($livros as $livro) {
	$livro->imprimir();
}

?>

</table>
