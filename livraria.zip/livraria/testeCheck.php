
<form name="form1" method="GET" action="carrinho.php">
  <input type="checkbox" name="livros[]" value="1">Java Como Programar<br>
  <input type="checkbox" name="livros[]" value="2">Redes de Computadores<br>
  <input type="checkbox" name="livros[]" value="3">Linguagens de Programação<br>
  <input type="checkbox" name="livros[]" value="4">Computação nas Nuvens<br>
  <input type="checkbox" name="livros[]" value="5">Android<br>
  <input type="submit" value="Submit">
</form>

